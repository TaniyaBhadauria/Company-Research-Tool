from __future__ import annotations

import json
from typing import List, Optional

import typer
from rich.progress import track

from .config import CONTINENTAL_US_STATES, SERVICE_QUERIES
from .db import Database, DB_PATH_DEFAULT
from .logging_utils import get_logger
from .utils import safe_json_dumps, safe_json_loads

from .scrapers.google_maps import iter_company_seeds as maps_seeds
from .scrapers.web_search import iter_company_seeds as web_seeds
from .scrapers.directories import iter_company_seeds_from_directory as dir_seeds

from .analyzers.site_crawler import crawl_site
from .analyzers.service_classifier import classify_services, exclusion_reason
from .analyzers.ownership_detector import detect_ownership

from .enrichers.linkedin_enricher import enrich_employee_count
from .enrichers.revenue_estimator import estimate_revenue

from .postprocess.dedupe import dedupe_pairs
from .postprocess.scoring import score_company

logger = get_logger(__name__)
app = typer.Typer(add_completion=False)

def _states_arg(states: str) -> List[str]:
    if states.lower() == "all":
        return CONTINENTAL_US_STATES
    return [s.strip().upper() for s in states.split(",") if s.strip()]

@app.command()
def seeds(
    db_path: str = str(DB_PATH_DEFAULT),
    states: str = "all",
    max_per_query: int = 20,
    run_web_search: bool = True,
    run_directories: bool = False,
):
    """PHASE 1: Collect raw company seeds."""
    db = Database(db_path)
    db.init()

    st_list = _states_arg(states)

    # Source A: Google Maps
    for row in track(maps_seeds(SERVICE_QUERIES, st_list, max_per_query=max_per_query), description="Google Maps seeds"):
        if not row.get("name"):
            continue
        db.upsert_company(row)

    # Source B: Web search
    if run_web_search:
        search_queries = [
            "R&D tax credit consulting firm",
            "cost segregation services firm",
            "work opportunity tax credit WOTC consulting firm",
            "sales and use tax consulting firm",
            "specialty tax advisory firm",
        ]
        for row in track(web_seeds(search_queries, max_results_per_query=30), description="Web search seeds"):
            if not row.get("name"):
                continue
            db.upsert_company(row)

    # Source C: Directories (optional)
    if run_directories:
        directory_urls = [
            # TODO: Add your chosen directory listing pages here.
        ]
        for row in track(dir_seeds(directory_urls), description="Directory seeds"):
            if not row.get("name"):
                continue
            db.upsert_company(row)

    logger.info("✅ PHASE 1 complete.")
    db.close()

@app.command()
def analyze(db_path: str = str(DB_PATH_DEFAULT)):
    """PHASE 2: Crawl websites and classify services + exclusions + ownership."""
    db = Database(db_path)
    db.init()

    companies = db.fetch_companies(where="(website IS NOT NULL AND website != '') AND (services_json IS NULL OR services_json = '')")
    for c in track(companies, description="Website analyze"):
        cid = int(c["id"])
        website = c["website"]
        try:
            pages = crawl_site(website)
            all_text = " ".join([p.text for p in pages if p.text])
            services, signals = classify_services(all_text)
            excl = exclusion_reason(all_text, services)
            ownership = detect_ownership(all_text)

            payload = {
                "services": services,
                "signals": signals,
            }

            db.update_company(cid, {
                "services_json": safe_json_dumps(payload),
                "is_excluded": 1 if excl else 0,
                "exclusion_reason": excl,
                "ownership_type": ownership,
            })
        except Exception as e:
            logger.warning(f"[analyze] failed {website}: {e}")

    logger.info("✅ PHASE 2 complete.")
    db.close()

@app.command()
def enrich(db_path: str = str(DB_PATH_DEFAULT)):
    """PHASE 3: Enrich employee count and estimate revenue."""
    db = Database(db_path)
    db.init()

    companies = db.fetch_companies(
        where="(employee_count IS NULL OR employee_count = 0) OR (estimated_revenue IS NULL)"
    )

    for c_row in track(companies, description="Enrichment"):
        c = dict(c_row)  # ✅ sqlite3.Row -> dict (so .get works)
        cid = int(c["id"])
        emp = c.get("employee_count")
        rev = c.get("estimated_revenue")

        updates = {}

        # Employee enrichment (placeholder currently returns None)
        if not emp:
            emp_new, method = enrich_employee_count(c.get("website"), c.get("name", ""))
            if emp_new:
                updates["employee_count"] = int(emp_new)

        # Revenue estimate if missing and we have employee count (new or existing)
        if rev is None:
            est, is_est = estimate_revenue(updates.get("employee_count") or emp)
            if est is not None:
                updates["estimated_revenue"] = float(est)

        if updates:
            db.update_company(cid, updates)

    logger.info("✅ PHASE 3 complete.")
    db.close()

@app.command()
def dedupe(db_path: str = str(DB_PATH_DEFAULT), name_threshold: int = 92):
    """PHASE 4: Deduplicate and score."""
    db = Database(db_path)
    db.init()

    # Build dict list for dedupe
    companies = [dict(r) for r in db.fetch_companies()]
    merges = dedupe_pairs(companies, name_threshold=name_threshold)

    # Apply merges: keep first, merge second (delete merged)
    for keep_id, merge_id, reason in track(merges, description="Deduplication"):
        # naive merge: prefer non-null fields from merged into kept (only if kept missing)
        kept = db.fetch_companies(where="id=?", params=(keep_id,))
        merged = db.fetch_companies(where="id=?", params=(merge_id,))
        if not kept or not merged:
            continue
        kept = dict(kept[0]); merged = dict(merged[0])

        updates = {}
        for field in ["city","state","website","phone","estimated_revenue","employee_count","ownership_type","key_contact","services_json","raw_snippet","source_url","data_source"]:
            if not kept.get(field) and merged.get(field):
                updates[field] = merged[field]

        # combine sources
        if kept.get("data_source") and merged.get("data_source") and kept["data_source"] != merged["data_source"]:
            updates["data_source"] = f"{kept['data_source']};{merged['data_source']}"

        if updates:
            db.update_company(keep_id, updates)

        db.insert_dedupe_map(keep_id, merge_id, reason)
        db.delete_company(merge_id)

    # Score all remaining
    remaining = [dict(r) for r in db.fetch_companies()]
    for r in track(remaining, description="Scoring"):
        score, _ = score_company(r)
        db.update_company(int(r["id"]), {"quality_score": float(score)})

    logger.info("✅ PHASE 4 complete.")
    db.close()

@app.command()
def run(
    db_path: str = str(DB_PATH_DEFAULT),
    states: str = "all",
    max_per_query: int = 20,
):
    """Run end-to-end pipeline."""
    seeds(db_path=db_path, states=states, max_per_query=max_per_query, run_web_search=True, run_directories=False)
    analyze(db_path=db_path)
    enrich(db_path=db_path)
    dedupe(db_path=db_path)

if __name__ == "__main__":
    app()
