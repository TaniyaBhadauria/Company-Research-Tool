from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Tuple

DB_PATH_DEFAULT = Path("data/exit_group.db")

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    city TEXT,
    state TEXT,
    website TEXT,
    phone TEXT,
    services_json TEXT,             -- JSON dict of service booleans + signals
    estimated_revenue REAL,
    employee_count INTEGER,
    ownership_type TEXT,
    key_contact TEXT,
    data_source TEXT,
    source_url TEXT,
    raw_snippet TEXT,
    is_excluded INTEGER DEFAULT 0,
    exclusion_reason TEXT,
    quality_score REAL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_companies_name_state_website
ON companies (name, state, website);

CREATE TABLE IF NOT EXISTS crawl_pages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    url TEXT NOT NULL,
    status_code INTEGER,
    content_type TEXT,
    fetched_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(company_id) REFERENCES companies(id)
);

CREATE TABLE IF NOT EXISTS dedupe_map (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kept_company_id INTEGER NOT NULL,
    merged_company_id INTEGER NOT NULL,
    reason TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(kept_company_id) REFERENCES companies(id),
    FOREIGN KEY(merged_company_id) REFERENCES companies(id)
);
"""


def _coerce_sqlite_value(v: Any) -> Any:
    """
    SQLite only supports a handful of primitive bind types.
    Convert lists/dicts/etc. to JSON strings so inserts never fail.
    """
    if v is None:
        return None
    if isinstance(v, (str, int, float, bytes)):
        return v
    # booleans are fine but treated as ints by sqlite
    if isinstance(v, bool):
        return int(v)

    # Convert common containers / objects to JSON string
    try:
        return json.dumps(v, ensure_ascii=False)
    except TypeError:
        return str(v)


class Database:
    def __init__(self, db_path: Path = DB_PATH_DEFAULT):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row

    def init(self) -> None:
        self.conn.executescript(SCHEMA_SQL)
        self.conn.commit()

    def upsert_company(self, row: Dict[str, Any]) -> int:
        # Best-effort upsert based on name/state/website uniqueness
        fields = [
            "name", "city", "state", "website", "phone", "services_json", "estimated_revenue", "employee_count",
            "ownership_type", "key_contact", "data_source", "source_url", "raw_snippet", "is_excluded",
            "exclusion_reason", "quality_score"
        ]
        data = {k: row.get(k) for k in fields}
        data["updated_at"] = row.get("updated_at")

        placeholders = ",".join(["?"] * len(fields))
        columns = ",".join(fields)
        values = [_coerce_sqlite_value(data[k]) for k in fields]

        try:
            cur = self.conn.execute(
                f"INSERT INTO companies ({columns}) VALUES ({placeholders})",
                values
            )
            self.conn.commit()
            return int(cur.lastrowid)

        except sqlite3.IntegrityError:
            # update matching row
            cur = self.conn.execute(
                "SELECT id FROM companies WHERE name=? AND state=? AND (website IS ? OR website = ?)",
                (_coerce_sqlite_value(data["name"]), _coerce_sqlite_value(data["state"]),
                 _coerce_sqlite_value(data["website"]), _coerce_sqlite_value(data["website"]))
            )
            existing = cur.fetchone()

            if not existing:
                # fallback: update by name/state only
                cur = self.conn.execute(
                    "SELECT id FROM companies WHERE name=? AND state=?",
                    (_coerce_sqlite_value(data["name"]), _coerce_sqlite_value(data["state"]))
                )
                existing = cur.fetchone()

            if not existing:
                raise

            company_id = int(existing["id"])

            set_clause = ",".join([f"{k}=?" for k in fields if k != "name"])
            upd_values = [_coerce_sqlite_value(data[k]) for k in fields if k != "name"] + [company_id]

            self.conn.execute(
                f"UPDATE companies SET {set_clause}, updated_at=datetime('now') WHERE id=?",
                upd_values
            )
            self.conn.commit()
            return company_id

    def fetch_companies(self, where: str = "1=1", params: Tuple[Any, ...] = ()) -> List[sqlite3.Row]:
        cur = self.conn.execute(f"SELECT * FROM companies WHERE {where}", params)
        return list(cur.fetchall())

    def update_company(self, company_id: int, updates: Dict[str, Any]) -> None:
        if not updates:
            return
        keys = list(updates.keys())
        set_clause = ",".join([f"{k}=?" for k in keys])
        values = [_coerce_sqlite_value(updates[k]) for k in keys] + [company_id]
        self.conn.execute(f"UPDATE companies SET {set_clause}, updated_at=datetime('now') WHERE id=?", values)
        self.conn.commit()

    def delete_company(self, company_id: int) -> None:
        self.conn.execute("DELETE FROM companies WHERE id=?", (company_id,))
        self.conn.commit()

    def insert_dedupe_map(self, kept_id: int, merged_id: int, reason: str) -> None:
        self.conn.execute(
            "INSERT INTO dedupe_map (kept_company_id, merged_company_id, reason) VALUES (?,?,?)",
            (kept_id, merged_id, reason)
        )
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()