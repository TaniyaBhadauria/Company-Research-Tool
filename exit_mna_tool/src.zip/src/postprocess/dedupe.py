from __future__ import annotations

from typing import Dict, List, Tuple
from rapidfuzz import fuzz
from ..utils import normalize_company_name, extract_domain

def dedupe_pairs(companies: List[Dict], name_threshold: int = 92) -> List[Tuple[int, int, str]]:
    """
    Returns list of (keep_id, merge_id, reason) pairs.
    Strategy:
      1) Same website domain => merge
      2) Very similar normalized name + same state => merge
    """
    by_domain = {}
    merges: List[Tuple[int,int,str]] = []

    for c in companies:
        cid = int(c["id"])
        dom = extract_domain(c.get("website"))
        if dom:
            if dom in by_domain:
                merges.append((by_domain[dom], cid, f"same_domain:{dom}"))
            else:
                by_domain[dom] = cid

    # Name+state fuzzy
    # O(n^2) is fine for 1k rows; for larger, use blocking by state or first token.
    comps = companies
    for i in range(len(comps)):
        a = comps[i]
        for j in range(i+1, len(comps)):
            b = comps[j]
            if (a.get("state") and b.get("state")) and a["state"] != b["state"]:
                continue
            na = normalize_company_name(a["name"])
            nb = normalize_company_name(b["name"])
            score = fuzz.token_sort_ratio(na, nb)
            if score >= name_threshold:
                keep = int(a["id"])
                merge = int(b["id"])
                merges.append((keep, merge, f"fuzzy_name:{score}"))
    # de-dup merge instructions
    seen = set()
    out = []
    for keep, merge, reason in merges:
        if keep == merge:
            continue
        key = (keep, merge)
        if key in seen:
            continue
        seen.add(key)
        out.append((keep, merge, reason))
    return out
