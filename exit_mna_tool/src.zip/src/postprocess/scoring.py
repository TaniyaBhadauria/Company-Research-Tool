from __future__ import annotations

from typing import Dict, Tuple
from ..config import THRESHOLDS
from ..utils import safe_json_loads

def score_company(company_row: Dict) -> Tuple[float, str | None]:
    """
    Simple quality score (0..10-ish) + exclusion check.
    """
    score = 0.0
    reason = None

    website = company_row.get("website")
    if website:
        score += 1.0

    services = safe_json_loads(company_row.get("services_json"))
    service_bools = services.get("services", {}) if isinstance(services, dict) else {}
    svc_count = sum(1 for v in service_bools.values() if v)

    if svc_count >= 1:
        score += 3.0
    if svc_count >= 2:
        score += 2.0

    emp = company_row.get("employee_count")
    rev = company_row.get("estimated_revenue")

    if isinstance(emp, int) and emp >= THRESHOLDS.min_employees:
        score += 2.0

    if isinstance(rev, (int, float)) and rev >= THRESHOLDS.min_revenue_usd:
        score += 2.0

    if company_row.get("ownership_type"):
        score += 1.0

    # Soft exclusion: if explicitly excluded by earlier phase, keep score but mark
    if company_row.get("is_excluded"):
        reason = company_row.get("exclusion_reason") or "excluded"
        score = max(0.0, score - 3.0)

    return score, reason
