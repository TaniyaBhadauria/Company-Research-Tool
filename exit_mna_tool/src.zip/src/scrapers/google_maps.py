from __future__ import annotations

import os
from typing import Dict, Iterable, Iterator, List, Optional
import requests

from ..logging_utils import get_logger
from ..config import USER_AGENT

logger = get_logger(__name__)

PLACES_TEXTSEARCH_URL = "https://maps.googleapis.com/maps/api/place/textsearch/json"
PLACES_DETAILS_URL = "https://maps.googleapis.com/maps/api/place/details/json"

def _api_key() -> str:
    key = os.getenv("GOOGLE_MAPS_API_KEY", "").strip()
    if not key:
        raise RuntimeError("GOOGLE_MAPS_API_KEY is not set.")
    return key

def text_search(query: str, region: str = "us", max_pages: int = 1, sleep_s: float = 2.0) -> List[Dict]:
    """Run Places Text Search. Returns raw Places results."""
    import time
    key = _api_key()
    results: List[Dict] = []
    page_token: Optional[str] = None
    headers = {"User-Agent": USER_AGENT}

    for _ in range(max_pages):
        params = {"query": query, "region": region, "key": key}
        if page_token:
            params["pagetoken"] = page_token
        resp = requests.get(PLACES_TEXTSEARCH_URL, params=params, headers=headers, timeout=20)
        resp.raise_for_status()
        data = resp.json()
        results.extend(data.get("results", []))
        page_token = data.get("next_page_token")
        if not page_token:
            break
        # Google requires a short delay before next_page_token becomes valid
        time.sleep(sleep_s)

    return results

def place_details(place_id: str, fields: str = "name,website,formatted_phone_number,geometry,formatted_address") -> Dict:
    key = _api_key()
    headers = {"User-Agent": USER_AGENT}
    params = {"place_id": place_id, "fields": fields, "key": key}
    resp = requests.get(PLACES_DETAILS_URL, params=params, headers=headers, timeout=20)
    resp.raise_for_status()
    return resp.json().get("result", {})

def iter_company_seeds(service_queries: Iterable[str], states: Iterable[str], max_per_query: int = 20) -> Iterator[Dict]:
    """
    Yields standardized seed rows from Google Maps.

    Output fields:
    - name, city, state, website, phone, data_source, source_url, raw_snippet
    """
    for st in states:
        for q in service_queries:
            query = f"{q} in {st}"
            logger.info(f"[GoogleMaps] textsearch: {query}")
            raw = text_search(query, max_pages=2)
            for r in raw[:max_per_query]:
                place_id = r.get("place_id")
                details = {}
                if place_id:
                    try:
                        details = place_details(place_id)
                    except Exception as e:
                        logger.warning(f"[GoogleMaps] details failed for {place_id}: {e}")

                name = details.get("name") or r.get("name")
                website = details.get("website")
                phone = details.get("formatted_phone_number")
                address = details.get("formatted_address") or r.get("formatted_address") or ""
                city = None
                state = st
                # Best-effort parse of city from address
                if address:
                    parts = [p.strip() for p in address.split(",")]
                    if len(parts) >= 2:
                        city = parts[-3] if len(parts) >= 3 else parts[0]

                yield {
                    "name": name,
                    "city": city,
                    "state": state,
                    "website": website,
                    "phone": phone,
                    "data_source": "google_maps_places",
                    "source_url": "google_maps_places_api",
                    "raw_snippet": r.get("types"),
                }
