from __future__ import annotations

from typing import Dict, Iterable, Iterator, List, Optional
import requests
from bs4 import BeautifulSoup

from ..logging_utils import get_logger
from ..config import USER_AGENT

logger = get_logger(__name__)

DUCKDUCKGO_HTML = "https://duckduckgo.com/html/"

def ddg_search(query: str, max_results: int = 30) -> List[Dict]:
    """
    Lightweight web search via DuckDuckGo HTML (no API key).
    Returns a list of dicts: {title, url, snippet}.
    """
    headers = {"User-Agent": USER_AGENT}
    resp = requests.post(DUCKDUCKGO_HTML, data={"q": query}, headers=headers, timeout=20)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")
    results: List[Dict] = []
    for r in soup.select(".result"):
        a = r.select_one("a.result__a")
        sn = r.select_one(".result__snippet")
        if not a:
            continue
        url = a.get("href")
        title = a.get_text(" ", strip=True)
        snippet = sn.get_text(" ", strip=True) if sn else None
        results.append({"title": title, "url": url, "snippet": snippet})
        if len(results) >= max_results:
            break
    return results

def iter_company_seeds(search_queries: Iterable[str], max_results_per_query: int = 30) -> Iterator[Dict]:
    """
    Produces seed rows from web search snippets. These are noisier than Maps.
    Output fields:
    - name (best-effort), website (result url), data_source, source_url, raw_snippet
    """
    for q in search_queries:
        logger.info(f"[WebSearch] ddg: {q}")
        for res in ddg_search(q, max_results=max_results_per_query):
            title = res.get("title") or ""
            # naive company name from title
            name = title.split("|")[0].split("-")[0].strip()[:200] or title[:200]
            yield {
                "name": name,
                "city": None,
                "state": None,
                "website": res.get("url"),
                "phone": None,
                "data_source": "web_search_ddg",
                "source_url": res.get("url"),
                "raw_snippet": res.get("snippet"),
            }
