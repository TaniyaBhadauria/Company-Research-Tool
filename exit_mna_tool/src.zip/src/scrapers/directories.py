from __future__ import annotations

from typing import Dict, Iterable, Iterator, List, Optional
import requests
from bs4 import BeautifulSoup

from ..logging_utils import get_logger
from ..config import USER_AGENT

logger = get_logger(__name__)

def iter_company_seeds_from_directory(urls: Iterable[str]) -> Iterator[Dict]:
    """
    Directory scraper scaffold.

    Provide URLs to directory pages that list firms (e.g., Clutch/UpCity listings).
    Each directory tends to have different HTML; implement per-site parsers here.

    Output fields:
    - name, city, state, website, data_source, source_url, raw_snippet
    """
    headers = {"User-Agent": USER_AGENT}
    for url in urls:
        logger.info(f"[Directory] fetch: {url}")
        try:
            resp = requests.get(url, headers=headers, timeout=20)
            resp.raise_for_status()
        except Exception as e:
            logger.warning(f"[Directory] failed {url}: {e}")
            continue

        soup = BeautifulSoup(resp.text, "html.parser")

        # TODO: Replace with site-specific selectors.
        # Fallback heuristic: find outbound links that look like firm websites.
        for a in soup.select("a[href]"):
            href = a.get("href", "")
            text = a.get_text(" ", strip=True)
            if not text or len(text) < 2:
                continue
            if "mailto:" in href or "tel:" in href:
                continue
            if href.startswith("#"):
                continue
            # crude filter: skip internal navigation
            if any(x in href for x in ["clutch.co", "upcity.com", "facebook.com", "linkedin.com", "twitter.com"]):
                continue

            yield {
                "name": text[:200],
                "city": None,
                "state": None,
                "website": href,
                "phone": None,
                "data_source": "directory_scrape",
                "source_url": url,
                "raw_snippet": None,
            }
