from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

# -------------------------
# Thesis / screening config
# -------------------------

CONTINENTAL_US_STATES = [
    "AL","AZ","AR","CA","CO","CT","DE","FL","GA","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI",
    "MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN",
    "TX","UT","VT","VA","WA","WV","WI","WY"
]

SERVICE_QUERIES = [
    "R&D tax credit consulting",
    "research and development tax credit",
    "cost segregation services",
    "cost segregation firm",
    "WOTC consulting",
    "work opportunity tax credit",
    "sales and use tax consulting",
    "specialty tax advisory",
]

# Keywords used to classify services on a firm's website
SERVICE_KEYWORDS: Dict[str, List[str]] = {
    "rd_tax_credits": [
        "r&d tax credit", "research and development tax credit", "section 41", "form 6765", "rd credits",
    ],
    "cost_segregation": [
        "cost segregation", "engineering-based study", "engineering study", "segregation study",
    ],
    "wotc": [
        "work opportunity tax credit", "wotc", "wotc screening", "wotc program",
    ],
    "sales_use_tax": [
        "sales and use tax", "sales tax consulting", "use tax", "sales tax audit defense", "sales tax compliance",
    ],
}

EXCLUSION_KEYWORDS = {
    "erc_primary": [
        "employee retention credit", "erc refund", "erc specialists", "erc filing",
    ],
    "property_tax_only": [
        "property tax appeal", "property tax consulting", "property tax reduction", "real estate tax appeal",
    ],
}

OWNERSHIP_KEYWORDS = {
    "pe_backed": [
        "portfolio company", "backed by", "private equity", "acquired by", "a leading investor",
    ],
    "public_company": [
        "nasdaq", "nyse", "investor relations", "10-k", "10q", "form 8-k",
    ],
}

@dataclass(frozen=True)
class Thresholds:
    min_employees: int = 6           # employee count > 5
    min_revenue_usd: float = 3_000_000.0

THRESHOLDS = Thresholds()

# Revenue-per-employee heuristic for professional services (used when only employee count is known)
REVENUE_PER_EMPLOYEE_USD = 200_000.0

# How many pages to fetch from a company website for classification
MAX_SITE_PAGES = 4
SITE_CRAWL_TIMEOUT_S = 10
USER_AGENT = "ExitGroupResearchBot/1.0 (contact: candidate@example.com)"
