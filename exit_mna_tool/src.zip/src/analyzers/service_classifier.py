from __future__ import annotations

from typing import Dict, List, Tuple
import re

from ..config import SERVICE_KEYWORDS, EXCLUSION_KEYWORDS

def _contains_any(text: str, keywords: List[str]) -> bool:
    t = text.lower()
    return any(k.lower() in t for k in keywords)

def classify_services(pages_text: str) -> Tuple[Dict[str, bool], Dict[str, List[str]]]:
    """
    Returns:
    - services: dict of booleans by service key
    - signals: dict with matched keywords per service
    """
    t = pages_text.lower()
    services: Dict[str, bool] = {}
    signals: Dict[str, List[str]] = {}
    for svc, kws in SERVICE_KEYWORDS.items():
        matched = [k for k in kws if k.lower() in t]
        services[svc] = len(matched) > 0
        if matched:
            signals[svc] = matched
    return services, signals

def exclusion_reason(pages_text: str, services: Dict[str, bool]) -> str | None:
    t = pages_text.lower()
    has_erc = _contains_any(t, EXCLUSION_KEYWORDS["erc_primary"])
    has_prop = _contains_any(t, EXCLUSION_KEYWORDS["property_tax_only"])

    # If it clearly focuses on ERC and none of the target services detected, exclude
    if has_erc and not any(services.values()):
        return "erc_primary_or_only"

    # Property tax only: exclude if property tax signals and no target services
    if has_prop and not any(services.values()):
        return "property_tax_only"

    return None
