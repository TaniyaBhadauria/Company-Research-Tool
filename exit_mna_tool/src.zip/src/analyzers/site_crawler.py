from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional, Set, Tuple
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from ..config import MAX_SITE_PAGES, SITE_CRAWL_TIMEOUT_S, USER_AGENT
from ..logging_utils import get_logger

logger = get_logger(__name__)

@dataclass
class Page:
    url: str
    status_code: Optional[int]
    content_type: Optional[str]
    text: str

def _clean_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    return soup.get_text(" ", strip=True)

def _candidate_links(base_url: str, html: str) -> List[str]:
    soup = BeautifulSoup(html, "html.parser")
    links: List[str] = []
    for a in soup.select("a[href]"):
        href = a.get("href", "").strip()
        if not href:
            continue
        full = urljoin(base_url, href)
        # keep same domain only
        if urlparse(full).netloc != urlparse(base_url).netloc:
            continue
        # prefer services/about pages
        if any(k in full.lower() for k in ["service", "solutions", "what-we-do", "capabilities", "about", "tax-credit", "cost-segregation", "wotc", "sales-tax"]):
            links.append(full)
    # de-dup while preserving order
    seen = set()
    out = []
    for l in links:
        if l not in seen:
            seen.add(l)
            out.append(l)
    return out

def crawl_site(start_url: str, max_pages: int = MAX_SITE_PAGES) -> List[Page]:
    headers = {"User-Agent": USER_AGENT}
    pages: List[Page] = []
    visited: Set[str] = set()

    queue: List[str] = [start_url]
    while queue and len(pages) < max_pages:
        url = queue.pop(0)
        if url in visited:
            continue
        visited.add(url)

        try:
            resp = requests.get(url, headers=headers, timeout=SITE_CRAWL_TIMEOUT_S, allow_redirects=True)
            status = resp.status_code
            ctype = resp.headers.get("content-type")
            if "text/html" not in (ctype or ""):
                pages.append(Page(url=url, status_code=status, content_type=ctype, text=""))
                continue

            text = _clean_text(resp.text)
            pages.append(Page(url=url, status_code=status, content_type=ctype, text=text))

            # add a few relevant internal links from the homepage only
            if len(pages) == 1:
                queue.extend(_candidate_links(resp.url, resp.text)[:max_pages])

        except Exception as e:
            logger.debug(f"[crawl] failed {url}: {e}")
            pages.append(Page(url=url, status_code=None, content_type=None, text=""))

    return pages
