from __future__ import annotations

from typing import Optional
from ..config import OWNERSHIP_KEYWORDS

def detect_ownership(pages_text: str) -> str | None:
    t = pages_text.lower()
    if any(k in t for k in [x.lower() for x in OWNERSHIP_KEYWORDS["public_company"]]):
        return "public_company"
    if any(k in t for k in [x.lower() for x in OWNERSHIP_KEYWORDS["pe_backed"]]):
        return "pe_backed"
    # If we can't tell, return None and keep it as unknown
    return None
