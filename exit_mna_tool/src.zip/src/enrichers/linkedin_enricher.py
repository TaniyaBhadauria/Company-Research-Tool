from __future__ import annotations

from typing import Optional, Tuple

def enrich_employee_count(website: Optional[str], company_name: str) -> Tuple[Optional[int], str]:
    """
    Placeholder for employee enrichment.

    IMPORTANT:
    - Direct scraping of LinkedIn may violate ToS.
    - Replace this with a compliant vendor API, manual entry, or other public sources.

    Returns:
    - employee_count (or None)
    - method/source label
    """
    # TODO: integrate a compliant enrichment source
    return None, "not_enriched"
