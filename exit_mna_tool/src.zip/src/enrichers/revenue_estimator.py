from __future__ import annotations

from typing import Optional, Tuple
from ..config import REVENUE_PER_EMPLOYEE_USD

def estimate_revenue(employee_count: Optional[int]) -> Tuple[Optional[float], bool]:
    """
    Simple heuristic: revenue ~= employees * revenue_per_employee.
    Returns (estimated_revenue, is_estimated_flag).
    """
    if employee_count is None:
        return None, False
    if employee_count <= 0:
        return None, False
    return float(employee_count) * float(REVENUE_PER_EMPLOYEE_USD), True
